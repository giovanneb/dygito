
// Substituído com o conteúdo do canvas
